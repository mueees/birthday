define(['jasmine'], function(jasmine){

	return describe('# first test', function(){

		it('$first it', function(){
			expect(1).toEqual(1);
		})

	});


})