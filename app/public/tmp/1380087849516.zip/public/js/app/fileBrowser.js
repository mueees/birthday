require([
    'app/app',
    'app/fileBrowser/fileBrowser_app'
], function(App){
    App.start();
})