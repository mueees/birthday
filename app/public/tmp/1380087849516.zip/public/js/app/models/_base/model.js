define(['backbone'], function(Backbone, App){
	return Backbone.Model.extend({});
})