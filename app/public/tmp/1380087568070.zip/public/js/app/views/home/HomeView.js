define([
    'marionette',
    'text!app/templates/home/HomeView.html'
], function(Marionette, template){

    return Marionette.ItemView.extend({
        template: _.template(template),

        events: {

        },

        ui: {

        },

        initialize: function(){

        },

        onRender: function(){

        }
    })

})