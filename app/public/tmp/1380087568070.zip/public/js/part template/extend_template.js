define([
    'marionette'
], function(Marionette, template){

    Marionette.AppRouter

})