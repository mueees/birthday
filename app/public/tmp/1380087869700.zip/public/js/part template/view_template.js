define([
    'marionette',
    'text!app/templates/...'
], function(Marionette, template){

    return Marionette.ItemView.extend({
        template: _.template(template),

        events: {

        },

        ui: {

        },

        initialize: function(){

        },

        onRender: function(){

        }
    })

})